//
//  ViewController.swift
//  Touchable View Demo
//
//  Created by Ahmadreza on 9/9/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstTouchableView: TouchableView!
    @IBOutlet weak var secondTouchableView: TouchableView!
    @IBOutlet weak var thirdTouchableView: TouchableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        firstTouchableView.layer.cornerRadius = 10
        secondTouchableView.layer.cornerRadius = 10
        thirdTouchableView.layer.cornerRadius = 10
        
        firstTouchableView.touchUpInside = {
            print("Third View Tap Action")
        }
    }
}

